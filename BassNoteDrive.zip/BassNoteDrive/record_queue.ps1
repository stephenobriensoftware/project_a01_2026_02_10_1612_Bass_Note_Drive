# Wrapper so you can run the queue script from inside bass_note_detect:
#   .\record_queue.ps1 -Mode capture -Set G0_5

$rootScript = Join-Path $PSScriptRoot "..\\record_queue.ps1"
& $rootScript @args

